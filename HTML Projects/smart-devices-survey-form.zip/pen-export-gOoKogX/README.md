# Smart Devices: Survey Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/ederekun/pen/gOoKogX](https://codepen.io/ederekun/pen/gOoKogX).

