# Edrick: Personal Portfolio

A Pen created on CodePen.io. Original URL: [https://codepen.io/ederekun/pen/KKQwbrm](https://codepen.io/ederekun/pen/KKQwbrm).

